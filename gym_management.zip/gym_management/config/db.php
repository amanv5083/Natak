<?php // PDO database connection will be written here (Step 4)
