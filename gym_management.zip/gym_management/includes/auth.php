<?php // includes/auth.php - will be written in a later step
