<?php // includes/header.php - will be written in a later step
