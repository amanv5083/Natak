<?php // includes/footer.php - will be written in a later step
