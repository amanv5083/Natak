<?php // includes/csrf.php - will be written in a later step
