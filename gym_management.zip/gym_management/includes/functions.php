<?php // includes/functions.php - will be written in a later step
