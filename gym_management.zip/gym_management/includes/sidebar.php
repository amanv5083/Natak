<?php // includes/sidebar.php - will be written in a later step
